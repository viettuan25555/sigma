package com.example.sigma.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.sigma.entity.ProductReview;

public interface ProductReviewRepository extends JpaRepository<ProductReview, Long> {
    List<ProductReview> findByProductIdAndStatusOrderByCreatedAtDesc(Long productId, String status);
}
