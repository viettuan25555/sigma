package com.example.sigma.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.sigma.entity.Agent;

public interface AgentRepository extends JpaRepository<Agent, Long> {
}
