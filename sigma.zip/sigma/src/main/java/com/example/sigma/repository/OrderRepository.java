package com.example.sigma.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.sigma.entity.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {
    long countBySaleId(Long saleId);
}
