package com.example.sigma.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.sigma.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
    List<Customer> findBySaleId(Long saleId);
}
