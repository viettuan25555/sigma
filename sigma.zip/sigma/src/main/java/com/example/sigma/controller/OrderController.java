package com.example.sigma.controller;

import java.util.Map;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.http.ResponseEntity;

import jakarta.transaction.Transactional;

import com.example.sigma.common.CrudController;
import com.example.sigma.entity.Order;
import com.example.sigma.repository.OrderRepository;
import com.example.sigma.repository.OrderItemRepository;
import com.example.sigma.repository.ProductRepository;

@RestController
@RequestMapping("/api/orders")
public class OrderController extends CrudController<Order> {
    private final OrderRepository repository;
    private final OrderItemRepository orderItemRepository;
    private final ProductRepository productRepository;

    public OrderController(OrderRepository repository, OrderItemRepository orderItemRepository, ProductRepository productRepository) {
        super(repository);
        this.repository = repository;
        this.orderItemRepository = orderItemRepository;
        this.productRepository = productRepository;
    }

    @GetMapping("/sale/{saleId}/count")
    public long countBySale(@PathVariable Long saleId) {
        return repository.countBySaleId(saleId);
    }

    @DeleteMapping("/{id}/sale/{saleId}")
    @Transactional
    public ResponseEntity<?> deleteSaleOrder(@PathVariable Long id, @PathVariable Long saleId) {
        var result = repository.findById(id);
        if (result.isEmpty()) return ResponseEntity.notFound().build();
        var order = result.get();
        if (order.getSaleId() == null || !order.getSaleId().equals(saleId)) {
            return ResponseEntity.status(403).body("Sale khong duoc xoa don nay");
        }
        if (!"ERROR".equalsIgnoreCase(order.getStatus())) {
            return ResponseEntity.badRequest().body("Chi duoc xoa don co trang thai ERROR");
        }
        var items = orderItemRepository.findByOrderId(id);
        for (var item : items) {
            if (item.getProductId() == null || item.getQuantity() == null) continue;
            productRepository.findById(item.getProductId()).ifPresent(product -> {
                product.setStock((product.getStock() == null ? 0 : product.getStock()) + item.getQuantity());
                productRepository.save(product);
            });
        }
        orderItemRepository.deleteAll(items);
        repository.delete(order);
        return ResponseEntity.ok(Map.of("message", "Da xoa don va hoan lai ton kho"));
    }
}
