package com.example.sigma.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.sigma.common.CrudController;
import com.example.sigma.entity.SaleTarget;
import com.example.sigma.repository.SaleTargetRepository;

@RestController
@RequestMapping("/api/sale-targets")
public class SaleTargetController extends CrudController<SaleTarget> {
    public SaleTargetController(SaleTargetRepository repository) {
        super(repository);
    }
}
