package com.example.sigma.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.sigma.entity.SaleAssignment;

public interface SaleAssignmentRepository extends JpaRepository<SaleAssignment, Long> {
}
