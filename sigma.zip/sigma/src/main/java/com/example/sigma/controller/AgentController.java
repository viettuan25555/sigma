package com.example.sigma.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.sigma.common.CrudController;
import com.example.sigma.entity.Agent;
import com.example.sigma.repository.AgentRepository;

@RestController
@RequestMapping("/api/agents")
public class AgentController extends CrudController<Agent> {
    public AgentController(AgentRepository repository) {
        super(repository);
    }
}
