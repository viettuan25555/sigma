package com.example.sigma.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.sigma.entity.Store;

public interface StoreRepository extends JpaRepository<Store, Long> {
}
