package com.example.sigma.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.sigma.common.CrudController;
import com.example.sigma.entity.Customer;
import com.example.sigma.repository.CustomerRepository;

@RestController
@RequestMapping("/api/customers")
public class CustomerController extends CrudController<Customer> {
    private final CustomerRepository repository;

    public CustomerController(CustomerRepository repository) {
        super(repository);
        this.repository = repository;
    }

    @GetMapping("/sale/{saleId}")
    public List<Customer> findBySale(@PathVariable Long saleId) {
        return repository.findBySaleId(saleId);
    }
}
