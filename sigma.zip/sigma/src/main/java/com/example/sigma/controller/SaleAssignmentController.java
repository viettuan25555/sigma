package com.example.sigma.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.sigma.common.CrudController;
import com.example.sigma.entity.SaleAssignment;
import com.example.sigma.repository.SaleAssignmentRepository;

@RestController
@RequestMapping("/api/sale-assignments")
public class SaleAssignmentController extends CrudController<SaleAssignment> {
    public SaleAssignmentController(SaleAssignmentRepository repository) {
        super(repository);
    }
}
