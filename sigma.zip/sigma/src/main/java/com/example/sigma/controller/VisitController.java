package com.example.sigma.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.sigma.common.CrudController;
import com.example.sigma.entity.Visit;
import com.example.sigma.repository.VisitRepository;

@RestController
@RequestMapping("/api/visits")
public class VisitController extends CrudController<Visit> {
    public VisitController(VisitRepository repository) {
        super(repository);
    }
}
