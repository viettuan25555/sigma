package com.example.sigma.config;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.sigma.entity.Category;
import com.example.sigma.entity.Product;
import com.example.sigma.entity.User;
import com.example.sigma.repository.CategoryRepository;
import com.example.sigma.repository.ProductRepository;
import com.example.sigma.repository.UserRepository;

@Configuration
public class DataSeeder {
    private static final String INVENTORY_FILE = "/inventory-seed.tsv";

    @Bean
    CommandLineRunner seedData(CategoryRepository categories, ProductRepository products, UserRepository users) {
        return args -> {
            removeLegacyDemoData(categories, products);
            seedInventory(categories, products);
            removeMergedCategories(categories);
            applyProductImages(products);

            saveUser(users, "Sigma Admin", "admin@sigma.vn", "admin123", "0983464028", "ADMIN", "ACTIVE");
            saveUser(users, "Sale Test", "saletest@sigma.vn", "saletest123", "0900000001", "SALE", "ACTIVE");
        };
    }

    private void saveCategory(CategoryRepository repository, String name, String code, String description) {
        Category category = repository.findByCode(code).orElseGet(Category::new);
        category.setName(fixMojibake(name));
        category.setCode(code);
        category.setDescription(fixMojibake(description));
        category.setStatus("ACTIVE");
        repository.save(category);
    }

    private void saveProduct(ProductRepository repository, String oldSku, String name, String sku, String category, int price, int stock, String status, String imageUrl, String description) {
        Product product = repository.findBySku(sku)
                .or(() -> oldSku == null ? java.util.Optional.empty() : repository.findBySku(oldSku))
                .orElseGet(Product::new);
        product.setName(fixMojibake(name));
        product.setSku(sku);
        product.setCategory(category);
        product.setPrice(BigDecimal.valueOf(price));
        product.setStock(stock);
        product.setStatus(status);
        product.setImageUrl(imageUrl);
        product.setDescription(fixMojibake(description));
        repository.save(product);
    }

    private void seedInventory(CategoryRepository categories, ProductRepository products) throws Exception {
        try (var stream = DataSeeder.class.getResourceAsStream(INVENTORY_FILE)) {
            if (stream == null) throw new IllegalStateException("Không tìm thấy " + INVENTORY_FILE);
            try (var reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.isBlank() || line.startsWith("#")) continue;
                    String[] fields = line.split("\\t", -1);
                    if ("CATEGORY".equals(fields[0])) {
                        saveCategory(categories, fields[2], fields[1], fields[3]);
                    } else if ("PRODUCT".equals(fields[0])) {
                        int stock = Integer.parseInt(fields[4]);
                        String status = stock == 0 ? "OUT_OF_STOCK" : stock <= 10 ? "LOW_STOCK" : "ACTIVE";
                        saveProduct(products, null, fields[2], fields[1], fields[3], 0, stock, status, null, fields[5]);
                    }
                }
            }
        }
    }

    private void removeLegacyDemoData(CategoryRepository categories, ProductRepository products) {
        for (String sku : new String[] { "SIG-SOLAR-100", "SIG-SOLAR-200", "SIG-SOLAR-400", "SIG-LED-30", "SIG-SEN-180" }) {
            products.findBySku(sku).ifPresent(products::delete);
        }
        for (String code : new String[] { "solar", "led", "smart" }) {
            categories.findByCode(code).ifPresent(categories::delete);
        }
    }

    private void removeMergedCategories(CategoryRepository categories) {
        categories.findByCode("den-op-noi-tran-vien-oval").ifPresent(categories::delete);
        categories.findByCode("bong-bulb-tru-nhom").ifPresent(categories::delete);
    }

    private void applyProductImages(ProductRepository products) {
        products.findAll().forEach(product -> {
            String imageUrl = imageForProduct(product);
            if (imageUrl != null && !imageUrl.equals(product.getImageUrl())) {
                product.setImageUrl(imageUrl);
                products.save(product);
            }
        });
    }

    private String imageForProduct(Product product) {
        String sku = product.getSku() == null ? "" : product.getSku();
        String category = product.getCategory() == null ? "" : product.getCategory();
        String name = product.getName() == null ? "" : product.getName().toLowerCase();
        String assetBase = "assets/products/";

        if (sku.contains("TV0") || name.contains("tràn viền")) return assetBase + "clean-den-op-noi-tran-vien-oval.jpg";
        if (category.equals("bong-bulb-tru-nhua-nhom") && !name.contains("nhựa")) return assetBase + "excel-bong-bulb-tru-nhom.webp";
        if (category.equals("bong-bulb-tru-nhua-nhom")) return assetBase + "excel-bong-bulb-tru-nhua-nhom.jpeg";
        if (category.equals("bong-bulb-tru-nhom")) return assetBase + "excel-bong-bulb-tru-nhom.webp";
        if (category.equals("den-tuyp-thuy-tinh-t8")) return assetBase + "clean-den-tuyp-thuy-tinh-t8.jpg";
        if (category.equals("den-tuyp-ban-nguyet")) return assetBase + "excel-den-tuyp-ban-nguyet.jpeg";
        if (category.equals("den-led-oval")) return assetBase + "excel-den-led-oval.png";
        if (category.equals("den-am-tran")) return assetBase + "excel-den-am-tran.jpeg";
        if (category.equals("den-op-tran-op-hien")) return assetBase + "excel-den-op-tran-op-hien.jpeg";
        if (category.equals("den-op-noi-tran-vien-oval")) return assetBase + "clean-den-op-noi-tran-vien-oval.jpg";
        if (category.equals("den-xuong")) return assetBase + "excel-den-xuong.jpeg";
        if (category.equals("den-panel")) return assetBase + "excel-den-panel.jpeg";
        if (category.equals("den-led-pha")) return assetBase + "excel-den-led-pha.jpeg";
        if (category.equals("den-led-pha-nang-luong-mat-troi")) return assetBase + "user-solar-floodlight.png";
        if (category.equals("day-led")) return assetBase + "user-day-led.png";
        if (category.equals("quat-tran-3-canh")) return assetBase + "excel-quat-tran-3-canh.jpeg";
        if (category.equals("quat-tran-van-go-co-den-led")) return assetBase + "excel-quat-tran-van-go-co-den-led.jpeg";
        if (category.equals("quat-suoi-da-nang")) return assetBase + "excel-quat-suoi-da-nang.jpeg";
        if (category.equals("den-suoi")) return assetBase + "excel-den-suoi.png";
        if (category.equals("quat-suoi-gom")) return assetBase + "excel-quat-suoi-gom.jpeg";
        if (category.equals("den-led-thap")) return assetBase + "den-led-thap-user.png";
        if (category.equals("den-nang-luong-giao-thong")) return "assets/categories/den-nang-luong-san-bai-giao-thong-v2.webp";
        if (category.equals("do-gia-dung")) return "assets/categories/do-gia-dung-v2.webp";
        if (category.equals("do-inox")) return "assets/categories/do-inox-v2.webp";
        if (category.equals("quat-nang-luong")) return "assets/categories/quat-nang-luong.webp";
        if (category.equals("nang-luong-ap-mai")) return "assets/categories/nang-luong-ap-mai-v2.webp";
        return null;
    }

    private String fixMojibake(String value) {
        if (value == null) return null;
        String fixed = value;
        for (int i = 0; i < 4 && looksMojibake(fixed); i++) {
            fixed = new String(fixed.getBytes(StandardCharsets.ISO_8859_1), StandardCharsets.UTF_8);
        }
        return fixed;
    }

    private boolean looksMojibake(String value) {
        return value.indexOf('\u00c3') >= 0 || value.indexOf('\u00c2') >= 0 || value.indexOf('\u00c4') >= 0;
    }

    private void saveUser(UserRepository repository, String name, String email, String password, String phone, String role, String status) {
        User user = repository.findByEmail(email).orElseGet(User::new);
        user.setName(name);
        user.setEmail(email);
        user.setPassword(password);
        user.setPhone(phone);
        user.setRole(role);
        user.setStatus(status);
        repository.save(user);
    }
}
