package com.example.sigma.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.sigma.common.CrudController;
import com.example.sigma.entity.Category;
import com.example.sigma.repository.CategoryRepository;

@RestController
@RequestMapping("/api/categories")
public class CategoryController extends CrudController<Category> {
    public CategoryController(CategoryRepository repository) {
        super(repository);
    }
}
