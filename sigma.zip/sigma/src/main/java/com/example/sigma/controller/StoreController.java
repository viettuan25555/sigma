package com.example.sigma.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.sigma.common.CrudController;
import com.example.sigma.entity.Store;
import com.example.sigma.repository.StoreRepository;

@RestController
@RequestMapping("/api/stores")
public class StoreController extends CrudController<Store> {
    public StoreController(StoreRepository repository) {
        super(repository);
    }
}
