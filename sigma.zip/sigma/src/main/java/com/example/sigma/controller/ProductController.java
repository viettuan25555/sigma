package com.example.sigma.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.sigma.common.CrudController;
import com.example.sigma.entity.Product;
import com.example.sigma.repository.ProductRepository;

@RestController
@RequestMapping("/api/products")
public class ProductController extends CrudController<Product> {
    public ProductController(ProductRepository repository) {
        super(repository);
    }
}
