package com.example.sigma.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.sigma.entity.ProductReview;
import com.example.sigma.repository.ProductRepository;
import com.example.sigma.repository.ProductReviewRepository;

@RestController
@RequestMapping("/api/reviews")
public class ProductReviewController {
    private final ProductReviewRepository repository;
    private final ProductRepository productRepository;

    public ProductReviewController(ProductReviewRepository repository, ProductRepository productRepository) {
        this.repository = repository;
        this.productRepository = productRepository;
    }

    @GetMapping("/product/{productId}")
    public List<ProductReview> findPublishedByProduct(@PathVariable Long productId) {
        return repository.findByProductIdAndStatusOrderByCreatedAtDesc(productId, "PUBLISHED");
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody ProductReview review) {
        if (review.getProductId() == null || !productRepository.existsById(review.getProductId())) {
            return ResponseEntity.badRequest().body("San pham khong ton tai");
        }
        if (review.getRating() == null || review.getRating() < 1 || review.getRating() > 5) {
            return ResponseEntity.badRequest().body("So sao phai tu 1 den 5");
        }
        String name = review.getReviewerName() == null ? "" : review.getReviewerName().trim();
        String comment = review.getComment() == null ? "" : review.getComment().trim();
        if (name.isEmpty() || name.length() > 120 || comment.length() < 3 || comment.length() > 1200) {
            return ResponseEntity.badRequest().body("Ten hoac noi dung danh gia khong hop le");
        }
        review.setId(null);
        review.setReviewerName(name);
        review.setComment(comment);
        review.setStatus("PUBLISHED");
        review.setCreatedAt(null);
        return ResponseEntity.ok(repository.save(review));
    }
}
