package com.example.sigma.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.sigma.entity.SaleTarget;

public interface SaleTargetRepository extends JpaRepository<SaleTarget, Long> {
}
