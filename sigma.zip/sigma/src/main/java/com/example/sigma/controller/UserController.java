package com.example.sigma.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.sigma.common.CrudController;
import com.example.sigma.entity.User;
import com.example.sigma.repository.UserRepository;

@RestController
@RequestMapping("/api/users")
public class UserController extends CrudController<User> {
    public UserController(UserRepository repository) {
        super(repository);
    }
}
