package com.example.sigma.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.sigma.entity.Visit;

public interface VisitRepository extends JpaRepository<Visit, Long> {
}
