package com.example.sigma.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.sigma.common.CrudController;
import com.example.sigma.entity.OrderItem;
import com.example.sigma.repository.OrderItemRepository;

@RestController
@RequestMapping("/api/order-items")
public class OrderItemController extends CrudController<OrderItem> {
    public OrderItemController(OrderItemRepository repository) {
        super(repository);
    }
}
