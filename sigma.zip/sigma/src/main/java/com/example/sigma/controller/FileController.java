package com.example.sigma.controller;

import java.io.IOException;
import java.text.Normalizer;
import java.time.LocalDate;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

@RestController
@RequestMapping("/api/files")
public class FileController {
    private final S3Client s3Client;
    private final String bucket;
    private final String publicEndpoint;

    public FileController(
            S3Client s3Client,
            @Value("${app.s3.bucket}") String bucket,
            @Value("${app.s3.public-endpoint}") String publicEndpoint) {
        this.s3Client = s3Client;
        this.bucket = bucket;
        this.publicEndpoint = publicEndpoint;
    }

    @PostMapping(value = "/images", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, String> uploadImage(@RequestParam("file") MultipartFile file) throws IOException {
        if (file.isEmpty()) {
            throw new IllegalArgumentException("File is empty");
        }
        String contentType = file.getContentType() == null ? MediaType.APPLICATION_OCTET_STREAM_VALUE : file.getContentType();
        if (!contentType.startsWith("image/")) {
            throw new IllegalArgumentException("Only image files are supported");
        }

        String key = "products/%s/%s-%s".formatted(
                LocalDate.now(),
                UUID.randomUUID(),
                sanitize(file.getOriginalFilename()));

        PutObjectRequest request = PutObjectRequest.builder()
                .bucket(bucket)
                .key(key)
                .contentType(contentType)
                .contentLength(file.getSize())
                .build();

        s3Client.putObject(request, RequestBody.fromBytes(file.getBytes()));

        String url = publicEndpoint.replaceAll("/$", "") + "/" + bucket + "/" + key;
        return Map.of("bucket", bucket, "key", key, "url", url);
    }

    private String sanitize(String filename) {
        String value = filename == null || filename.isBlank() ? "image" : filename;
        String normalized = Normalizer.normalize(value, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return normalized.replaceAll("[^A-Za-z0-9._-]", "-");
    }
}
